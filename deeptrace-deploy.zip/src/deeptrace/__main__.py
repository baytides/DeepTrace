"""Allow running as python -m deeptrace."""

from deeptrace.main import app

app()
