"""DeepTrace - Cold case investigation platform."""

__version__ = "0.1.0"
